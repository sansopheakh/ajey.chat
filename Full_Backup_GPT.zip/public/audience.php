<?php require __DIR__.'/includes/db.php'; require __DIR__.'/includes/auth_guard.php'; require __DIR__.'/includes/header.php'; ?>
<div class="card">
  <h3 style="margin-top:0">Audience</h3>
  <div style="display:flex;gap:8px;margin-bottom:12px">
    <button class="btn ghost">Import CSV</button>
    <button class="btn ghost">Export CSV</button>
  </div>
  <table class="table">
    <thead><tr><th>Name</th><th>Tags</th><th>Last Event</th></tr></thead>
    <tbody><tr><td>—</td><td>—</td><td>—</td></tr></tbody>
  </table>
</div>
<?php require __DIR__.'/includes/footer.php'; ?>
