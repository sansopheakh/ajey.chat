<?php
echo password_hash("Admin@123", PASSWORD_BCRYPT);
