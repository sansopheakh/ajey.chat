<?php require __DIR__.'/../includes/db.php'; require __DIR__.'/../includes/functions.php'; require_login(); if(!role_in(['Owner','Admin'])) die('Forbidden'); include __DIR__.'/../partials_header.php';
$org = (int)($_SESSION['org_id']??0);
$res = $conn->query("SELECT id,name,email,role FROM users WHERE org_id=".$org." ORDER BY id DESC");
?>
<div class="card">
  <h3>Users</h3>
  <table class="table"><thead><tr><th>Name</th><th>Email</th><th>Role</th></tr></thead>
  <tbody>
    <?php while($r=$res->fetch_assoc()): ?>
      <tr><td><?=e($r['name'])?></td><td><?=e($r['email'])?></td><td><span class="badge"><?=e($r['role'])?></span></td></tr>
    <?php endwhile; ?>
  </tbody></table>
</div>
<?php include __DIR__.'/../partials_footer.php'; ?>
