<?php require __DIR__.'/../includes/db.php'; require __DIR__.'/../includes/functions.php'; require_login(); if(!role_in(['Owner','Admin'])) die('Forbidden'); include __DIR__.'/../partials_header.php'; ?>
<div class="grid cols-3">
  <div class="card"><h3>Users</h3><a class="btn ghost" href="/admin/users.php">Manage</a></div>
  <div class="card"><h3>Compliance</h3><p>Data export/delete placeholders</p></div>
  <div class="card"><h3>Partner API Keys</h3><p>Facebook App creds placeholder</p></div>
</div>
<?php include __DIR__.'/../partials_footer.php'; ?>
