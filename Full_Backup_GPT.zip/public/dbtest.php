<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$user = "puleeshop_fb_automation";
$pass = "2E!,!09fbx<Iy+Lm";  // full password
$db   = "puleeshop_fb_automation";

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_errno) {
    echo "❌ Failed to connect MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
} else {
    echo "✅ Database connection OK!";
}
?>
