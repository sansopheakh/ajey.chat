CREATE TABLE IF NOT EXISTS organizations(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(191) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  name VARCHAR(191) NOT NULL,
  email VARCHAR(191) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('Owner','Admin','Agent') NOT NULL DEFAULT 'Agent',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS subscriptions(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  plan VARCHAR(50) DEFAULT 'starter',
  status ENUM('active','trialing','past_due','canceled') DEFAULT 'trialing',
  current_period_end DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS invoices(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  user_id INT,
  amount_cents INT NOT NULL DEFAULT 0,
  currency VARCHAR(8) DEFAULT 'USD',
  status ENUM('paid','due','failed') DEFAULT 'due',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS analytics_events(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  event VARCHAR(64) NOT NULL,
  meta JSON,
  occurred_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS pages(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  fb_page_id VARCHAR(64),
  name VARCHAR(191),
  access_token TEXT,
  connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
);

INSERT INTO organizations (id, name) VALUES (1, 'Default Org')
ON DUPLICATE KEY UPDATE name=VALUES(name);

INSERT INTO users (org_id, name, email, password, role) VALUES
(1, 'Administrator', 'admin@afovob.net', '$2b$12$/5TSoNDnSOBKcD7r/o6a/etvezcoDLk95FiRslVzKykSKHQ/fnf2C', 'Owner')
ON DUPLICATE KEY UPDATE name=VALUES(name), password=VALUES(password), role=VALUES(role);
