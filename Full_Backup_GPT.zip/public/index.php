<?php
require __DIR__ . '/includes/db.php';
if (isset($_SESSION['user_id'])) { header("Location: /dashboard.php"); exit; }
header("Location: /login.php"); exit;
