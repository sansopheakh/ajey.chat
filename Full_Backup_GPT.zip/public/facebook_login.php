<?php
session_start();

$app_id = "2160667127788207";
$redirect_uri = "https://afovob.net/facebook_callback.php";

// ✅ Request only safe permissions for now
$scopes = "pages_show_list,pages_read_engagement,pages_manage_metadata";

$fb_login_url = "https://www.facebook.com/v19.0/dialog/oauth?" . http_build_query([
    'client_id' => $app_id,
    'redirect_uri' => $redirect_uri,
    'scope' => $scopes,
    'response_type' => 'code',
]);

header("Location: $fb_login_url");
exit();
