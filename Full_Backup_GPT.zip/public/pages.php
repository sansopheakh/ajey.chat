<?php
session_start();

if (!isset($_SESSION['fb_access_token'])) {
    header("Location: login.php");
    exit;
}

$access_token = $_SESSION['fb_access_token'];

// Fetch user’s connected pages
$graph_url = "https://graph.facebook.com/me/accounts?access_token={$access_token}";
$response = file_get_contents($graph_url);
$pages = json_decode($response, true);

if (isset($pages['error'])) {
    die("Graph API Error: " . $pages['error']['message']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Connected Pages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .page-card { max-width: 280px; margin: 15px; }
        .page-img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; }
    </style>
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Connected Facebook Pages</h2>
        <a href="facebook_login.php" class="btn btn-primary">+ Add New Page</a>
    </div>

    <div class="row">
        <?php if (!empty($pages['data'])): ?>
            <?php foreach ($pages['data'] as $page): ?>
                <div class="col-md-4">
                    <div class="card page-card shadow-sm">
                        <div class="card-body text-center">
                            <img src="https://graph.facebook.com/<?= $page['id']; ?>/picture?type=large&access_token=<?= $page['access_token']; ?>"
                                 class="page-img mb-3"
                                 onerror="this.src='fallback.png';">
                            <h5 class="card-title"><?= htmlspecialchars($page['name']); ?></h5>
                            <p class="text-muted">Page ID: <?= $page['id']; ?></p>
                            <a href="#" class="btn btn-sm btn-outline-primary">Manage</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No connected pages found. Click "Add New Page" to connect one.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
