<?php
session_start();
include 'db.php';

// Make sure the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You must log in first.");
}

$app_id = "2160667127788207";
$app_secret = "41b1336ba43a8e4c67ea660051697311";
$redirect_uri = "https://afovob.net/fb-callback.php";

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // 1. Exchange code for access token
    $token_url = "https://graph.facebook.com/v19.0/oauth/access_token?" .
        "client_id=$app_id&redirect_uri=" . urlencode($redirect_uri) .
        "&client_secret=$app_secret&code=$code";

    $response = file_get_contents($token_url);
    $data = json_decode($response, true);

    if (isset($data['access_token'])) {
        $access_token = $data['access_token'];
        $_SESSION['fb_access_token'] = $access_token;

        // 2. Get FB user profile
        $profile_url = "https://graph.facebook.com/me?fields=id,name&access_token=" . $access_token;
        $profile = json_decode(file_get_contents($profile_url), true);

        $fb_user_id = $profile['id'];
        $fb_name = $profile['name'];
        $user_id = $_SESSION['user_id'];

        // 3. Store token in DB (insert or update)
        $stmt = $conn->prepare("INSERT INTO user_facebook_tokens (user_id, fb_user_id, fb_name, access_token) 
                                VALUES (?, ?, ?, ?)
                                ON DUPLICATE KEY UPDATE fb_name=VALUES(fb_name), access_token=VALUES(access_token)");
        $stmt->bind_param("isss", $user_id, $fb_user_id, $fb_name, $access_token);
        $stmt->execute();

        // 4. Fetch and store pages
        $pages_url = "https://graph.facebook.com/v19.0/me/accounts?fields=id,name,fan_count,access_token&access_token=" . $access_token;
        $pages = json_decode(file_get_contents($pages_url), true);

        if (!empty($pages['data'])) {
            foreach ($pages['data'] as $page) {
                $page_id = $page['id'];
                $page_name = $page['name'];
                $fan_count = $page['fan_count'] ?? 0;
                $page_token = $page['access_token'];

                $stmt2 = $conn->prepare("INSERT INTO user_facebook_pages (user_id, page_id, page_name, fan_count, access_token)
                                         VALUES (?, ?, ?, ?, ?)
                                         ON DUPLICATE KEY UPDATE page_name=VALUES(page_name), fan_count=VALUES(fan_count), access_token=VALUES(access_token)");
                $stmt2->bind_param("issis", $user_id, $page_id, $page_name, $fan_count, $page_token);
                $stmt2->execute();
            }
        }

        // Redirect to pages dashboard
        header("Location: pages.php");
        exit();
    } else {
        echo "Error getting access token";
    }
} else {
    echo "Error: No code returned";
}
