<?php require __DIR__ . '/../../config.php'; ?>
<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Afovob Automate</title>
<link rel="stylesheet" href="/assets/css/style.css">
<script>window.CSRF="<?=csrf_token()?>";</script>
<script src="/assets/js/app.js" defer></script>
</head><body>
<nav class="topnav">
  <div class="wrap">
    <div class="brand">⚡ Afovob Automate</div>
    <ul class="nav">
      <?php if(is_logged_in()): ?>
      <li><a href="/">Dashboard</a></li>
      <li><a href="/pages.php">Pages</a></li>
      <li><a href="/inbox.php">Inbox</a></li>
      <li><a href="/flows.php">Flows</a></li>
      <li><a href="/auto-reply.php">Auto‑Reply</a></li>
      <li><a href="/broadcasts.php">Broadcasts</a></li>
      <li><a href="/audience.php">Audience</a></li>
      <li><a href="/analytics.php">Analytics</a></li>
      <li><a href="/billing.php">Billing</a></li>
      <?php if(role_in(['Owner','Admin'])): ?><li><a href="/admin/index.php">Admin</a></li><?php endif; ?>
      <?php endif; ?>
    </ul>
    <div class="right">
      <?php if(is_logged_in()): ?>
        <span class="badge">Org #<?= (int)($_SESSION['org_id']??0) ?></span>
        <a class="btn ghost" href="/logout.php">Logout</a>
      <?php else: ?>
        <a class="btn ghost" href="/login.php">Login</a>
        <a class="btn primary" href="/register.php">Sign Up</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
<main class="container">
