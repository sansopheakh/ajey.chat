<?php
session_start();
require 'db.php'; // your DB connection file

$app_id       = "2160667127788207";
$app_secret   = "41b1336ba43a8e4c67ea660051697311";
$redirect_uri = "https://afovob.net/facebook_callback.php";

if (isset($_GET['code'])) {
    // Exchange code for access token
    $token_url = "https://graph.facebook.com/v18.0/oauth/access_token?" . http_build_query([
        "client_id" => $app_id,
        "redirect_uri" => $redirect_uri,
        "client_secret" => $app_secret,
        "code" => $_GET['code']
    ]);

    $response = file_get_contents($token_url);
    $params = json_decode($response, true);

    if (!isset($params['access_token'])) {
        die("Error getting access token: " . $response);
    }

    $access_token = $params['access_token'];

    // Get user profile
    $graph_url = "https://graph.facebook.com/me?fields=id,name,email&access_token=" . $access_token;
    $user_info = json_decode(file_get_contents($graph_url), true);

    if (!isset($user_info['id'])) {
        die("Error fetching user info.");
    }

    $fb_user_id = $user_info['id'];
    $fb_user_name = $user_info['name'];
    $fb_user_email = isset($user_info['email']) ? $user_info['email'] : null;

    // ✅ Save user into local `users` table (if not exists)
    $stmt = $conn->prepare("INSERT INTO users (facebook_id, name, email) 
        VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), email = VALUES(email)");
    $stmt->bind_param("sss", $fb_user_id, $fb_user_name, $fb_user_email);
    $stmt->execute();

    // Get local user_id
    $stmt = $conn->prepare("SELECT id FROM users WHERE facebook_id = ?");
    $stmt->bind_param("s", $fb_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user_row = $result->fetch_assoc();
    $user_id = $user_row['id'];

    $_SESSION['user_id'] = $user_id;

    // ✅ Fetch user’s Facebook pages
    $pages_url = "https://graph.facebook.com/me/accounts?fields=id,name,fan_count,access_token&access_token=" . $access_token;
    $pages = json_decode(file_get_contents($pages_url), true);

    if (isset($pages['data'])) {
        foreach ($pages['data'] as $page) {
            $fb_page_id = $page['id'];
            $page_name  = $page['name'];
            $page_token = $page['access_token'];
            $fan_count  = isset($page['fan_count']) ? $page['fan_count'] : 0;

            // Insert or update into `user_facebook_pages`
            $stmt = $conn->prepare("INSERT INTO user_facebook_pages (user_id, page_id, page_name, fan_count, access_token) 
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    page_name = VALUES(page_name), 
                    fan_count = VALUES(fan_count), 
                    access_token = VALUES(access_token)");
            $stmt->bind_param("issis", $user_id, $fb_page_id, $page_name, $fan_count, $page_token);
            $stmt->execute();
        }
    }

    // ✅ Redirect to connected pages list
    header("Location: pages.php");
    exit();
} else {
    die("Error: No code parameter received from Facebook.");
}
?>
