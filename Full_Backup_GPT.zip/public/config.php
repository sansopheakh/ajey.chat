<?php
// Facebook App Credentials
define('FB_APP_ID', '2160667127788207');
define('FB_APP_SECRET', '41b1336ba43a8e4c67ea660051697311');
define('FB_REDIRECT_URI', 'https://afovob.net/facebook_callback.php');

// Permissions needed
define('FB_PERMISSIONS', 'pages_show_list,pages_read_engagement,pages_manage_metadata,pages_messaging,pages_manage_posts');
