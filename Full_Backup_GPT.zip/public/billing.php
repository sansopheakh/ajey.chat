<?php $active='billing'; include 'header.php'; ?>
<div class="flex flex-col lg:flex-row gap-8">
  <div class="flex-grow">
    
<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
  <div class="bg-white p-6 rounded-25 shadow-sm flex items-center justify-between">
    <div><p class="text-sm text-gray-500">Connected Pages</p><p class="text-3xl font-bold">5</p></div>
    <div class="bg-blue-600 text-white w-12 h-12 flex items-center justify-center rounded-full"><span class="material-icons">facebook</span></div>
  </div>
  <div class="bg-white p-6 rounded-25 shadow-sm flex items-center justify-between">
    <div><p class="text-sm text-gray-500">Chat Flows</p><p class="text-3xl font-bold">12</p></div>
    <div class="bg-orange-400 text-white w-12 h-12 flex items-center justify-center rounded-full"><span class="material-icons">chat_bubble_outline</span></div>
  </div>
  <div class="bg-white p-6 rounded-25 shadow-sm flex items-center justify-between">
    <div><p class="text-sm text-gray-500">Subscriber</p><p class="text-3xl font-bold">8</p></div>
    <div class="bg-blue-400 text-white w-12 h-12 flex items-center justify-center rounded-full"><span class="material-icons">notifications_none</span></div>
  </div>
  <div class="bg-white p-6 rounded-25 shadow-sm flex items-center justify-between">
    <div><p class="text-sm text-gray-500">Reply Campaign</p><p class="text-3xl font-bold">25</p></div>
    <div class="bg-green-400 text-white w-12 h-12 flex items-center justify-center rounded-full"><span class="material-icons">campaign</span></div>
  </div>
</div>

    <div class="grid grid-cols-1 gap-6 mt-8">
      <div class="bg-white p-6 rounded-25 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-lg font-semibold">Billing</h2>
          <a class="text-sm text-purple-600 hover:underline" href="#">Actions</a>
        </div>
        
   <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
     <div class="bg-white p-6 rounded-25 shadow-sm border">
       <p class="font-semibold">Starter</p><p class="text-3xl font-bold mt-2">$19</p>
       <button class="mt-4 px-4 py-2 bg-purple-600 text-white rounded-25 w-full">Choose</button>
     </div>
     <div class="bg-white p-6 rounded-25 shadow-sm border">
       <p class="font-semibold">Growth</p><p class="text-3xl font-bold mt-2">$49</p>
       <button class="mt-4 px-4 py-2 bg-purple-600 text-white rounded-25 w-full">Choose</button>
     </div>
     <div class="bg-white p-6 rounded-25 shadow-sm border">
       <p class="font-semibold">Pro</p><p class="text-3xl font-bold mt-2">$99</p>
       <button class="mt-4 px-4 py-2 bg-purple-600 text-white rounded-25 w-full">Choose</button>
     </div>
   </div>
   <div class="mt-8 bg-white p-6 rounded-25 shadow-sm">
     <h3 class="font-semibold mb-3">Invoices</h3>
     <div class="overflow-x-auto">
       <table class="min-w-full text-sm">
         <thead><tr class="text-left text-gray-500"><th class="py-2 pr-6">Invoice</th><th class="py-2 pr-6">Date</th><th class="py-2 pr-6">Amount</th><th class="py-2 pr-6">Status</th></tr></thead>
         <tbody>
           <tr class="border-t"><td class="py-2 pr-6">#0001</td><td class="py-2 pr-6">2025-08-01</td><td class="py-2 pr-6">$49</td><td class="py-2"><span class="px-3 py-1 text-xs rounded-25 bg-green-100 text-green-700">Paid</span></td></tr>
           <tr class="border-t"><td class="py-2 pr-6">#0002</td><td class="py-2 pr-6">2025-09-01</td><td class="py-2 pr-6">$49</td><td class="py-2"><span class="px-3 py-1 text-xs rounded-25 bg-yellow-100 text-yellow-700">Due</span></td></tr>
         </tbody>
       </table>
     </div>
   </div>
   
      </div>
    </div>
  </div>
  
<aside class="w-full lg:w-80 bg-white/80 backdrop-blur-md shadow-lg p-6 flex-shrink-0 rounded-25">
  <div class="flex flex-col items-center">
    <div class="relative">
      <img class="w-24 h-24 rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBtbVfYK5ku-w8s6aFEQZrTQqPKvzB4Ygu4tQ8xIt01CRnYQYEItsNqdHUXgGjqqNH9DEAFbi6FUQhA0N3Bv_2pTyjEN9FTyW9DKtODYzmKapCf0lvVS3IgARNtXyP9BA5Am7fJwtdVFn2moz1QVBSWJ_d3jMSd3MFM2QW9WNdHCh2MYLUaBt2CO07m1TYTDUAW_BXYXI4HtBpbsteMp6fJ7un8gPGEYUB9I3fYRzJc7lbaxWdiW4CjcX_XlveMp9FLhfv4KVqFAVcF" alt="avatar"/>
      <span class="absolute bottom-0 right-0 block h-6 w-6 rounded-full bg-green-400 border-4 border-white"></span>
    </div>
    <h2 class="text-xl font-semibold mt-4">Welcome Annie!</h2>
    <p class="text-sm text-gray-500">Owner</p>
  </div>
  <div class="mt-8">
    <h3 class="text-sm font-semibold text-gray-500 uppercase tracking-wider">Inbox</h3>
    <div class="mt-4 space-y-3">
      <div class="flex items-center gap-3 bg-white p-3 rounded-25 shadow-sm">
        <span class="material-icons text-purple-500">account_circle</span>
        <div><p class="font-medium">John Doe</p><p class="text-xs text-gray-500">loren</p></div>
      </div>
      <div class="flex items-center gap-3 bg-white p-3 rounded-25 shadow-sm">
        <span class="material-icons text-orange-400">account_circle</span>
        <div><p class="font-medium">Stephanie</p><p class="text-xs text-gray-500">Clisared</p></div>
      </div>
      <div class="flex items-center gap-3 bg-white p-3 rounded-25 shadow-sm">
        <span class="material-icons text-teal-500">account_circle</span>
        <div><p class="font-medium">Alex</p><p class="text-xs text-gray-500">Mideor</p></div>
      </div>
    </div>
  </div>
</aside>

</div>
<?php include 'footer.php'; ?>
