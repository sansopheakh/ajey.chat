<?php
// Set $active to highlight current menu, e.g. $active='dashboard';
$active = $active ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Ajey.chat</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"/>
<style type="text/tailwindcss">
  body { font-family: 'Poppins', sans-serif; background-image: linear-gradient(to bottom right, #f3e8ff, #faf5ff); }
  .rounded-25 { border-radius: 25px; }
  .nav-pill { @apply px-4 py-2 text-sm font-semibold tracking-wide uppercase rounded-25 transition; }
  .nav-active { @apply bg-white/20 text-white shadow-sm; }
  .nav-idle { @apply text-white/80 hover:text-white; }
  @screen lg { .container { max-width: 1440px; } }
</style>
</head>
<body class="text-gray-800">
<header class="sticky top-0 z-50 shadow-md">
  <div class="bg-gradient-to-r from-purple-700 to-purple-500">
    <div class="container mx-auto px-6 py-4">
      <div class="flex items-center justify-between">
        <a href="dashboard.php" class="flex items-center gap-3">
          <span class="text-2xl md:text-3xl font-extrabold text-white tracking-wide">AJEY.CHAT</span>
        </a>
        <nav class="hidden md:flex items-center gap-2">
          <a href="dashboard.php" class="nav-pill <?php echo $active==='dashboard'?'nav-active':'nav-idle'; ?>">Dashboard</a>
          <a href="pages.php" class="nav-pill <?php echo $active==='pages'?'nav-active':'nav-idle'; ?>">Pages</a>
          <a href="chatflow.php" class="nav-pill <?php echo $active==='chatflow'?'nav-active':'nav-idle'; ?>">Chat Flow</a>
          <a href="replycomment.php" class="nav-pill <?php echo $active==='replycomment'?'nav-active':'nav-idle'; ?>">Reply Comment</a>
          <a href="broadcast.php" class="nav-pill <?php echo $active==='broadcast'?'nav-active':'nav-idle'; ?>">Broadcast</a>
          <a href="inbox.php" class="nav-pill <?php echo $active==='inbox'?'nav-active':'nav-idle'; ?>">Inbox</a>
          <a href="analytics.php" class="nav-pill <?php echo $active==='analytics'?'nav-active':'nav-idle'; ?>">Analytics</a>
          <a href="billing.php" class="nav-pill <?php echo $active==='billing'?'nav-active':'nav-idle'; ?>">Billing</a>
          <a href="admin.php" class="nav-pill <?php echo $active==='admin'?'nav-active':'nav-idle'; ?>">Admin</a>
        </nav>
        <button id="mobileBtn" class="md:hidden text-white">
          <span class="material-icons">menu</span>
        </button>
      </div>
      <div id="mobileNav" class="hidden md:hidden mt-3 border-t border-white/20 pt-3 flex flex-wrap gap-2">
        <a href="dashboard.php" class="nav-pill <?php echo $active==='dashboard'?'nav-active':'nav-idle'; ?>">Dashboard</a>
        <a href="pages.php" class="nav-pill <?php echo $active==='pages'?'nav-active':'nav-idle'; ?>">Pages</a>
        <a href="chatflow.php" class="nav-pill <?php echo $active==='chatflow'?'nav-active':'nav-idle'; ?>">Chat Flow</a>
        <a href="replycomment.php" class="nav-pill <?php echo $active==='replycomment'?'nav-active':'nav-idle'; ?>">Reply Comment</a>
        <a href="broadcast.php" class="nav-pill <?php echo $active==='broadcast'?'nav-active':'nav-idle'; ?>">Broadcast</a>
        <a href="inbox.php" class="nav-pill <?php echo $active==='inbox'?'nav-active':'nav-idle'; ?>">Inbox</a>
        <a href="analytics.php" class="nav-pill <?php echo $active==='analytics'?'nav-active':'nav-idle'; ?>">Analytics</a>
        <a href="billing.php" class="nav-pill <?php echo $active==='billing'?'nav-active':'nav-idle'; ?>">Billing</a>
        <a href="admin.php" class="nav-pill <?php echo $active==='admin'?'nav-active':'nav-idle'; ?>">Admin</a>
      </div>
    </div>
  </div>
</header>
<main class="container mx-auto px-6 py-8">
