<?php require __DIR__.'/includes/db.php'; require __DIR__.'/includes/auth_guard.php'; require __DIR__.'/includes/header.php'; ?>
<div class="card">
  <div style="display:flex;gap:8px;align-items:center;margin-bottom:12px">
    <button class="btn ghost">Import</button>
    <button class="btn ghost">Export</button>
    <button class="btn primary">Create Flow</button>
  </div>
  <div style="height:420px;background:#fafaff;border-radius:18px;display:grid;place-items:center;color:#6b7280">
    Node editor placeholder (Trigger → Condition → AI → Send → Collect → Action)
  </div>
</div>
<?php require __DIR__.'/includes/footer.php'; ?>
