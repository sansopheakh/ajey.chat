<?php require __DIR__.'/includes/db.php'; require __DIR__.'/includes/functions.php'; require_login(); include __DIR__.'/partials_header.php'; ?>
<div class="card">
  <h3>Broadcasts</h3>

<div class="grid cols-3">
  <div><label>Segment</label><select><option>All within 24h</option></select></div>
  <div><label>Schedule</label><input class="input" type="datetime-local"></div>
  <div><label>Rate</label><input class="input" placeholder="msgs/min"></div>
</div>
<div style="margin-top:10px"><textarea class="input" rows="4" placeholder='Message JSON template'></textarea></div>
<div style="margin-top:10px"><button class="btn primary">Queue Broadcast</button></div>

</div>
<?php include __DIR__.'/partials_footer.php'; ?>
