<?php require __DIR__.'/includes/db.php'; require __DIR__.'/includes/functions.php'; require_login(); include __DIR__.'/partials_header.php'; ?>
<div class="card">
  <h3>Flow Builder</h3>

<div style="display:flex;gap:10px;align-items:center">
  <button class="btn ghost">Import</button>
  <button class="btn ghost">Export</button>
  <button class="btn primary">Create Flow</button>
</div>
<div style="margin-top:12px;height:420px;background:#fafaff;border-radius:16px;display:grid;place-items:center;color:#777">
  Visual node editor placeholder (Trigger → Condition → AI → Send → Collect → Action)
</div>

</div>
<?php include __DIR__.'/partials_footer.php'; ?>
