<?php
$DB_HOST = "localhost";
$DB_NAME = "puleeshop_fb_automation";
$DB_USER = "puleeshop_fb_automation";
$DB_PASS = "2E!,!09fbx<Iy+Lm";
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) { die("DB connection failed: " . $conn->connect_error); }
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
?>
