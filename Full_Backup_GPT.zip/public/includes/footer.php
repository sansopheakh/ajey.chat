</main>
  <footer>© <?php echo date('Y'); ?> Afovob Automate</footer>
</body>
</html>
