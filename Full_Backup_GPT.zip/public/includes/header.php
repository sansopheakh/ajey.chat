<?php if (session_status() !== PHP_SESSION_ACTIVE) session_start(); ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Afovob Automate</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <nav class="topnav">
    <span class="brand">Afovob</span>
    <a href="/dashboard.php">Dashboard</a>
    <a href="/inbox.php">Inbox</a>
    <a href="/flowbuilder.php">Flow Builder</a>
    <a href="/autoreply.php">Auto‑Reply</a>
    <a href="/broadcast.php">Broadcast</a>
    <a href="/audience.php">Audience</a>
    <a href="/analytics.php">Analytics</a>
    <a href="/billing.php">Billing</a>
    <a href="/settings.php">Settings</a>
    <span class="spacer"></span>
    <?php if (!empty($_SESSION['email'])): ?>
      <span class="badge"><?php echo htmlspecialchars($_SESSION['email']); ?></span>
      <a href="/logout.php">Logout</a>
    <?php else: ?>
      <a href="/login.php">Login</a>
    <?php endif; ?>
  </nav>
  <main class="container">
