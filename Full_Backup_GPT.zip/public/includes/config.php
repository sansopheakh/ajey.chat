<?php
define("APP_URL", "https://afovob.net/");
define("PAYPAL_CLIENT_ID", "YOUR_SANDBOX_CLIENT_ID");
define("PAYPAL_SECRET", "YOUR_SANDBOX_SECRET");
define("PAYPAL_BASE_URL", "https://api-m.sandbox.paypal.com");
?>
