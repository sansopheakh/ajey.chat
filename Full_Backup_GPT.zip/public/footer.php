
</main>
<script>
  const btn = document.getElementById('mobileBtn');
  const nav = document.getElementById('mobileNav');
  if (btn && nav) btn.addEventListener('click',()=>nav.classList.toggle('hidden'));
</script>
</body>
</html>
