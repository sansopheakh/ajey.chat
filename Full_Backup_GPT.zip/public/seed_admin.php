<?php
require __DIR__ . '/includes/db.php';
$email = 'admin@afovob.net';
$pass = 'Admin@123';
$hash = password_hash($pass, PASSWORD_BCRYPT);
$role = 'Owner';
$stmt = $conn->prepare("INSERT INTO users (email,password,role) VALUES (?,?,?) ON DUPLICATE KEY UPDATE password=VALUES(password), role=VALUES(role)");
$stmt->bind_param("sss", $email, $hash, $role);
$stmt->execute();
echo "Seeded admin user: $email / $pass";
