async function post(url,data){
  const res = await fetch(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(Object.assign({_token:window.CSRF},data||{}))});
  if(!res.ok) throw new Error('Request failed'); return res.text();
}
