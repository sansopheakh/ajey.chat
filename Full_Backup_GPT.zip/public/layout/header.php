<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AJEY.CHAT</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- FontAwesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <style>
    body {
      background: #f6f3fb;
      font-family: 'Inter', sans-serif;
    }
    /* Navbar */
    .navbar {
      background: linear-gradient(90deg, #8b5cf6, #6366f1);
      padding: 1rem 2rem;
    }
    .navbar-brand {
      font-size: 1.6rem;
      font-weight: 700;
      color: white !important;
      letter-spacing: 1px;
    }
    .navbar-nav .nav-link {
      color: white !important;
      font-weight: 500;
      margin: 0 12px;
      transition: 0.3s;
    }
    .navbar-nav .nav-link:hover,
    .navbar-nav .nav-link.active {
      text-decoration: underline;
    }

    /* Cards */
    .stat-card {
      background: white;
      border-radius: 16px;
      padding: 20px;
      text-align: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .stat-icon {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 10px auto;
      font-size: 22px;
      color: white;
    }

    /* Buttons */
    .btn-gradient {
      background: linear-gradient(90deg, #8b5cf6, #6366f1);
      color: white !important;
      border-radius: 8px;
      padding: 8px 18px;
      font-weight: 500;
      border: none;
      transition: 0.3s;
    }
    .btn-gradient:hover {
      opacity: 0.9;
    }

    /* Sidebar (profile) */
    .sidebar-card {
      background: white;
      border-radius: 16px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .user-avatar {
      width: 70px;
      height: 70px;
      border-radius: 50%;
      margin-bottom: 10px;
      border: 3px solid #8b5cf6;
    }
    .inbox-item {
      display: flex;
      align-items: center;
      margin: 10px 0;
      padding: 8px;
      border-radius: 10px;
      background: #f9f7fd;
    }
    .inbox-item i {
      font-size: 20px;
      margin-right: 10px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">AJEY.CHAT</a>
    <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'pages.php' ? 'active' : '' ?>" href="pages.php">Pages</a></li>
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'chatflow.php' ? 'active' : '' ?>" href="chatflow.php">Chat Flow</a></li>
        <li class="nav-item"><a class="nav-link" href="replycomment.php">Reply Comment</a></li>
        <li class="nav-item"><a class="nav-link" href="broadcast.php">Broadcast</a></li>
        <li class="nav-item"><a class=
