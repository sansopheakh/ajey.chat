<?php include 'header.php'; ?>
<h2>Register</h2>
<div class="card">
  <form method="post" action="">
    <input type="email" name="email" placeholder="Email" required style="width:100%;padding:10px;border-radius:25px;margin-bottom:10px;">
    <input type="password" name="password" placeholder="Password" required style="width:100%;padding:10px;border-radius:25px;margin-bottom:10px;">
    <button type="submit">Register</button>
  </form>
</div>
<?php include 'footer.php'; ?>
