<?php require __DIR__.'/includes/db.php'; require __DIR__.'/includes/auth_guard.php'; require __DIR__.'/includes/header.php'; ?>
<div class="grid cols-2">
  <div class="card">
    <h3 style="margin-top:0">Organization</h3>
    <label>Name</label><input class="input" placeholder="Default Org">
    <div style="margin-top:10px"><button class="btn primary">Save</button></div>
  </div>
  <div class="card">
    <h3 style="margin-top:0">Profile</h3>
    <label>Email</label><input class="input" value="<?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?>">
    <div style="margin-top:10px"><button class="btn primary">Update</button></div>
  </div>
</div>
<?php require __DIR__.'/includes/footer.php'; ?>
