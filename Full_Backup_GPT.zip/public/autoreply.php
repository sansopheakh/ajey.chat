<?php require __DIR__.'/includes/db.php'; require __DIR__.'/includes/auth_guard.php'; require __DIR__.'/includes/header.php'; ?>
<div class="card">
  <h3 style="margin-top:0">Auto‑Reply Rules</h3>
  <div class="grid cols-2">
    <div><label>Keyword / Regex</label><input class="input" placeholder="e.g. (price|cost)"></div>
    <div><label>Sentiment ≥</label><select class="input"><option>0.2</option><option>0.5</option><option>0.8</option></select></div>
  </div>
  <div style="margin-top:10px"><button class="btn primary">Save Rule</button></div>
  <table class="table" style="margin-top:12px">
    <thead><tr><th>Pattern</th><th>Hidden</th><th>Reply</th></tr></thead>
    <tbody><tr><td>—</td><td>No</td><td>—</td></tr></tbody>
  </table>
</div>
<?php require __DIR__.'/includes/footer.php'; ?>
