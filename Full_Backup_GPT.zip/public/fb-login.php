<?php
session_start();

$app_id = "2160667127788207";
$redirect_uri = "https://afovob.net/fb-callback.php";
$scope = "pages_show_list,pages_read_engagement,pages_read_user_content"; 

$login_url = "https://www.facebook.com/v19.0/dialog/oauth?client_id=$app_id&redirect_uri=" . urlencode($redirect_uri) . "&scope=" . urlencode($scope);

header("Location: $login_url");
exit();
