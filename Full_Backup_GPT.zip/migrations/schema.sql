CREATE TABLE IF NOT EXISTS organizations(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(191) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  name VARCHAR(191) NOT NULL,
  email VARCHAR(191) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('Owner','Admin','Agent') NOT NULL DEFAULT 'Agent',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS pages(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  fb_page_id VARCHAR(64),
  name VARCHAR(191),
  access_token TEXT,
  connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS inbox_threads(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  page_id INT NOT NULL,
  type ENUM('messenger','comment') NOT NULL,
  external_id VARCHAR(191) NOT NULL,
  subject VARCHAR(255),
  status ENUM('open','snoozed','closed') DEFAULT 'open',
  assignee INT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS inbox_messages(
  id INT AUTO_INCREMENT PRIMARY KEY,
  thread_id INT NOT NULL,
  sender VARCHAR(191),
  body TEXT,
  direction ENUM('in','out') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS flows(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  page_id INT NOT NULL,
  name VARCHAR(191) NOT NULL,
  json MEDIUMTEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS rules(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  page_id INT NOT NULL,
  type ENUM('comment_keyword','comment_regex') NOT NULL,
  pattern VARCHAR(255) NOT NULL,
  sentiment_threshold DECIMAL(3,2) DEFAULT 0.00,
  hidden TINYINT(1) DEFAULT 0,
  reply_text TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS broadcasts(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  page_id INT NOT NULL,
  segment VARCHAR(191),
  template JSON,
  schedule_at DATETIME,
  rate_per_min INT DEFAULT 60,
  status ENUM('queued','running','done','failed') DEFAULT 'queued'
);
CREATE TABLE IF NOT EXISTS contacts(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  page_id INT NOT NULL,
  external_id VARCHAR(191),
  name VARCHAR(191),
  tags JSON,
  attributes JSON,
  last_event_at TIMESTAMP NULL
);
CREATE TABLE IF NOT EXISTS invoices(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  user_id INT,
  amount_cents INT NOT NULL DEFAULT 0,
  currency VARCHAR(8) DEFAULT 'USD',
  status ENUM('paid','due','failed') DEFAULT 'due',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS usage_events(
  id INT AUTO_INCREMENT PRIMARY KEY,
  org_id INT NOT NULL,
  page_id INT,
  kind VARCHAR(50),
  qty INT DEFAULT 1,
  occurred_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
